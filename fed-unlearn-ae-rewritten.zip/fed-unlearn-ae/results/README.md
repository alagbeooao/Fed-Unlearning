Per-run evaluation output goes here, one JSON per (seed, forgotten client):

    results_seed42_forget0.json
    results_seed42_forget2.json
    results_seed123_forget0.json
    results_seed123_forget2.json
    results_seed2024_forget0.json
    results_seed2024_forget2.json

Section 9 of notebooks/run_experiments.ipynb copies them here after a run.
